let minhaNotaNoTp;
minhaNotaNoTp = 10;

alert(minhaNotaNoTp);
console.log(minhaNotaNoTp);