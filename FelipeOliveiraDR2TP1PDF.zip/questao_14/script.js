let massa = prompt("Digite o valor da massa do objeto");
let massaN = Number(massa);

let acc = prompt("Digite a aceleração");
let accN = Number(acc);

let forca = massa * acc;
alert("O total da força é " + forca + " Newtons");

let trabalho = prompt("Digite o trabalho realizado");
let trabalhoN = Number(trabalho);

let tempo = prompt("Digite o tempo gasto");
let tempoN = Number(tempo);

let potencia = trabalho / tempo;
alert("A potência é " + potencia + " Watts");