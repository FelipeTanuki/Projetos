let primeiroNumero = prompt("Digite um numero");
let primeiroNumeroConvertido = Number(primeiroNumero);

let segundoNumero = prompt("Digite outro numero");
let segundoNumeroConvertido = Number(segundoNumero);

let adicao = primeiroNumeroConvertido + segundoNumeroConvertido
let subtracao = primeiroNumeroConvertido - segundoNumeroConvertido
let multiplicacao = primeiroNumeroConvertido * segundoNumeroConvertido
let divisao = primeiroNumeroConvertido / segundoNumeroConvertido

console.log("Adição " + adicao);
console.log("Subtração " + subtracao);
console.log("Multiplicação " + multiplicacao);
console.log("Divisão " + divisao);