let distancia = prompt("Digite o valor da distancia percorrida");
let distanciaN = Number(distancia);

let tempo = prompt("Digite o total do tempo gasto");
let tempoN = Number(tempo);

let total = distanciaN / tempoN;
alert("A velocidade media é: " + total + " metros por segundo");