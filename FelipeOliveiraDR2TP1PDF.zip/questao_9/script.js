let massa = prompt("Digite o valor da massa");
let massaN = Number(massa);

let vel = prompt("Digite o valor da velocidade");
let velN = Number(vel);

let energia = 0.5 * massaN * Math.pow(velN, 2);
alert("A energia cinética total é: " + energia + " Joules.");