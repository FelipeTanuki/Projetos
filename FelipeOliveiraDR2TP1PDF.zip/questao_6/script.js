let aleatorio = Math.random();
console.log(aleatorio);