// Programação é o processo de criar instruções que um computador pode seguir para executar tarefas específicas.

// JavaScript é uma linguagem de programação amplamente usada para criar interatividade em páginas web.

/*
JavaScript é uma ferramenta usada para tornar páginas web interativas e responsivas. 
Ele permite que os desenvolvedores criem elementos dinâmicos, como animações, formulários que respondem às ações do usuário e até mesmo jogos. No navegador, o JavaScript executa essas funções, melhorando a experiência do usuário sem precisar recarregar a página inteira.
*/