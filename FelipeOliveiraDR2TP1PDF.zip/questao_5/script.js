var resposta_usuario = prompt("Come você está hoje?");
console.log(resposta_usuario);