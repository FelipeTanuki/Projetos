// Não modifique as sentenças seguintes
let numA;
let numB;
let numC;
let numD;

// Modifique aqui os valores!
numA = 4;
numB = 1;
numC = 3;
numD = 4;

// Não modifique as sentenças seguintes

numA++;
numC = numB--;
numC++;
numA = ++numD;
console.log("A: " + numA)
console.log("B: " + numB)
console.log("C: " + numC)
console.log("D: " + numD)
const resultado = numA + numB + numC + numD;
console.log("Total: " + resultado);